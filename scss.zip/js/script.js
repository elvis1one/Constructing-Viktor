




//-------------------animation-text

const animItems = document.querySelectorAll('._anim-items');

if (animItems.length > 0) {
	window.addEventListener('scroll', animOnScroll);

	function offset(el) {
		const rect = el.getBoundingClientRect(),
			scrollLeft = window.scrollX || document.documentElement.scrollLeft,
			scrollTop = window.scrollY || document.documentElement.scrollTop;
		return { top: rect.top + scrollTop, left: rect.left + scrollLeft }
	}


	function animOnScroll() {
		for (let index = 0; index < animItems.length; index++) {
			const animItem = animItems[index];
			const animItemHeight = animItem.offsetHeight;
			const animItemOffset = offset(animItem).top;
			const animStart = 4;

			let animItemPoint = window.innerHeight - animItemHeight / animStart;
			if (animItemHeight > window.innerHeight) {
				animItemPoint = window.innerHeight - window.innerHeight / animStart;
			}

			if ((scrollY > animItemOffset - animItemPoint) && scrollY < (animItemOffset + animItemHeight)) {
				animItem.classList.add('_active');
			} else {
				if (!animItem.classList.contains('_anim-no-hide')) {
					animItem.classList.remove('_active');
				}
			}
		}
	}

	setTimeout(() => {
		animOnScroll();
	}, 500);
}



//===============form to e-mail=======
$(document).ready(function () {

	//E-mail Ajax Send
	$("form").submit(function () { //Change
		var th = $(this);
		$.ajax({
			type: "POST",
			url: "mail.php", //Change
			data: th.serialize()
		}).done(function () {
			alert("Дякуємо! Ваші дані успішно надіслано");
			setTimeout(function () {
				// Done Functions
				th.trigger("reset");
			}, 1000);
		});
		return false;
	});

});




//=======================validation form==============
function validation(form) {
	function removeError(input) {
		const parent = input.parentNode;

		if (parent.classList.contains('error')) {
			parent.querySelector('.error-label').remove();
			parent.classList.remove('error');
		}
	}

	function createError(input, text) {
		const parent = input.parentNode;
		const errorLabel = document.createElement('label');

		errorLabel.classList.add('error-label');

		errorLabel.textContent = text;
		parent.classList.add('error');
		parent.append(errorLabel);
	}

	let result = true;

	form.querySelectorAll('input').forEach(input => {
		removeError(input);
		if (input.value === '') {
			createError(input, 'Поле не заповнене');
			result = false;
		}
	});

	return result;
}




document.getElementById('form').addEventListener('submit', function (event) {
	event.preventDefault();

	if (validation(document.getElementById('form')) == true) {
		alert("Дякуємо! Запит надіслано успішно!");
	}
})